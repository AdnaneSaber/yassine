(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(student)_layout_tsx_7e1796._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(student)_layout_tsx_7e1796._.js",
  "chunks": [
    "static/chunks/node_modules_fc3ed7._.js",
    "static/chunks/_506ad4._.js"
  ],
  "source": "dynamic"
});
