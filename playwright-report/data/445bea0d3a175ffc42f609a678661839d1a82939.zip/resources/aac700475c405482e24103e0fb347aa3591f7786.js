(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(student)_demandes_new_page_tsx_156453._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(student)_demandes_new_page_tsx_156453._.js",
  "chunks": [
    "static/chunks/_975039._.js",
    "static/chunks/node_modules_zod_v4_d003d1._.js",
    "static/chunks/node_modules_e2ebb6._.js"
  ],
  "source": "dynamic"
});
