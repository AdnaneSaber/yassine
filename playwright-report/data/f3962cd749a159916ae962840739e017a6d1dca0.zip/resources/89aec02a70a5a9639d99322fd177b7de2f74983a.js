(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(student)_demandes_page_tsx_156453._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(student)_demandes_page_tsx_156453._.js",
  "chunks": [
    "static/chunks/node_modules_fc62dc._.js",
    "static/chunks/_51a6ba._.js"
  ],
  "source": "dynamic"
});
